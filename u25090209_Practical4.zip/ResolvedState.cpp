#include "ResolvedState.h"
#include "ResponseTask.h"


// --- ResolvedState ----------------------------------------------------
ResolvedState* ResolvedState::instance() {
    static ResolvedState instance;
    return &instance;
}
